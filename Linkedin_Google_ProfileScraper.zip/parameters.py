""" filename: parameters.py """


# search query 
search_query = 'site:linkedin.com/in/ AND "health economics outcomes research" AND "CANADA" AND ("manager" OR "director")'
gpage_start = 0 #Page Number to start search, Zero is the first results
gpage_stop = 20 #Last search page

# file were scraped profile information will be stored  
file_name = 'results_file001.xlsx'

# login credentials
linkedin_username = 'name@email.com' #Insert your email address here
linkedin_password = 'password123' #Insert your password